/**
 * pThread program to adjust speed according to the environmental factors like traffic signal and pedestrian
 *
 * @author  Ramya Manjunath
 * @version 20-02-2022
 */

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

double d_speed; // Speed of the platoon truck
int trafficLight = 0; // variable to store the color of the traffic light
int objDetected = 0; // variable to store the type of object detected
int objDetFlag = 0; // variable to set the object detected flag
pthread_mutex_t mutexCounter = PTHREAD_MUTEX_INITIALIZER;

#define TRUCK_NUM 4

typedef struct{
    pthread_t leadVehcle_tid;
    double d_dist;
    double d_time;
}trajDefaults;

/*
FunctionName  : vehSpeedCalculator
Description   : Calculates vehicle speed of the trucks
param[in]     : type double u_distance
param[in]     : type double u_time
param[out]    : none
return        : none
*/
void vehSpeedCalculator(double u_distance, double u_time)
{
   d_speed = u_distance/u_time;
}

/*
FunctionName  : setvehSpeedCalculator
Description   : sets vehicle distance and intended time of travel
param[in]     : type double u_distance
param[in]     : type double u_time
param[out]    : none
return        : none
*/
void setvehSpeedCalculator(double u_distance,double u_time)
{
    vehSpeedCalculator(u_distance, u_time);
}

/*
FunctionName  : getvehSpeedCalculator
Description   : gets vehicle speed
param[in]     : void
param[out]    : none
return        : type double veh_speed
*/
double getvehSpeedCalculator()
{
    double veh_speed = d_speed;
    return veh_speed;
}

/*
FunctionName  : trafficSignalChecker
Description   : checks the traffic light and adjusts the speed accordingly
param[in]     : int mySignal
param[in]     : double s_speed
param[out]    : none
return        : type double mySpeed
*/
double trafficSignalChecker(int mySignal, double s_speed){

    double mySpeed = s_speed;
    switch(mySignal){
    case 2: // Pedestrian detected or Red signal
        mySpeed = 0;
        break;
    default: // No obstacles
        mySpeed = s_speed;
        break;
    };
    return mySpeed;
}

/*
FunctionName  : leadVehicle
Description   : Thread function to set the trajectory data
param[in]     : trajDefaults *trajData
param[out]    : none
return        : type void pointer
*/
void *leadVehicle(trajDefaults *trajData)
{
    printf("Inside Platoon Manager Thread\n");
    setvehSpeedCalculator(trajData->d_dist, trajData->d_time);
}

/*
FunctionName  : followVehicle1
Description   : Thread function to fetch speed, and performs traffic signal and object detection
param[in]     : void *folTruck
param[out]    : none
return        : type void pointer
*/
void *followVehicle1(void *folTruck){

    int *fTruckData = (int*)folTruck;

    printf("Inside Platoon Vehicle Thread: %d\n", *fTruckData);
    static int count = 0;

    pthread_mutex_lock(&mutexCounter);
    double veh_speed = trafficSignalChecker(trafficLight, getvehSpeedCalculator());

    if(objDetFlag){
        if(objDetected == 1)
        {
            printf("Pedestrian detected\n\n");
            printf("Applying Emergency Brakes\n\n");
        }
        else
        {
            printf("No obstacle detected, cruising at normal speed!!\n\n");
        }
    }

    printf("Vehicle[%d] cruising at speed %lf kmph\n", count, veh_speed);
    count++;
    if(count > TRUCK_NUM){ count = 0;}
    pthread_mutex_unlock(&mutexCounter);
    return NULL;
 }

 /*
FunctionName  : main
Description   : reads input from the user and creates threads for parallel operation of truck platooning
param[in]     : int argc, char *argv[]
param[out]    : none
return        : type int
*/
int main(int argc, char *argv[])
{
    pthread_t *threadFollowVehicle_1;
    double distance= 0;
    double time = 0;
    int i = 0;
    trajDefaults trajData;

    srand(10);
    distance = (rand() % 1000) + 500;
    time = (rand() % 10) + 1;

    printf("\nAssuming the Platoon connection is successful!!!\n\n");
    printf("Setting trajectory defaults....\n");

    printf("The distance to be traveled: %lf\n\n", distance);
    printf("Intended time of travel: %lf\n\n", time);

    printf("Number of trucks in the platoon: %d\n", TRUCK_NUM);

    trajData.d_dist = distance;
    trajData.d_time = time;

    pthread_mutex_init(&mutexCounter, NULL);
    //Creating Main thread for Leader truck to manage the data
    if(pthread_create(&trajData.leadVehcle_tid,NULL,leadVehicle,(trajDefaults*)(&trajData)) != 0)
    {
        printf("ERROR: return code from pthread_create() threadLeadVehicle id = %d\n", trajData.leadVehcle_tid);
        exit(-1);
    }

    // Waits until leadVehcle_tid finishes its operation
    pthread_join(trajData.leadVehcle_tid,NULL);

    threadFollowVehicle_1 =(pthread_t *)malloc(TRUCK_NUM * sizeof(pthread_t ));

    for(i = 0; i<=TRUCK_NUM; i++)
    {
        //creating threads depending
        if(pthread_create(&threadFollowVehicle_1[i],NULL,followVehicle1,(void*)&threadFollowVehicle_1[i]) != 0)
        {
            printf("ERROR: return code from pthread_create threadFollowVehicle_1\n");
            exit(-1);
        }
    }

    for(i=0;i<=TRUCK_NUM;i++)
    {
        pthread_join(threadFollowVehicle_1[i],NULL);
    }

    printf("\n Platoon is in cruising Mode...\n");
    printf("\n Traffic Signal Detected! \n");
    printf("Choose the traffic Light!\n 0 - Green\n 2 - Red\n ");
    scanf("%d",&trafficLight);

    threadFollowVehicle_1 =(pthread_t *)malloc(TRUCK_NUM * sizeof(pthread_t ));

    for(i = 0; i<=TRUCK_NUM; i++)
    {
        //creating threads depending
        if(pthread_create(&threadFollowVehicle_1[i],NULL,followVehicle1,(void*)&threadFollowVehicle_1[i]) != 0)
        {
            printf("ERROR: return code from pthread_create threadFollowVehicle_1\n");
            exit(-1);
        }
    }

    for(i=0;i<=TRUCK_NUM;i++)
    {
        pthread_join(threadFollowVehicle_1[i],NULL);
    }

    printf("\n Platoon is in cruising Mode...\n");
    printf("\n Object status check! \n");
    printf("Choose the Obstacle:!\n 0 - No Obstacle\n 1 - Pedestrian\n ");
    scanf("%d",&objDetected);
    objDetFlag = 1;

    threadFollowVehicle_1 =(pthread_t *)malloc(TRUCK_NUM * sizeof(pthread_t ));

    for(i = 0; i<=TRUCK_NUM; i++)
    {
        //creating threads depending
        if(pthread_create(&threadFollowVehicle_1[i],NULL,followVehicle1,(void*)&threadFollowVehicle_1[i]) != 0)
        {
            printf("ERROR: return code from pthread_create threadFollowVehicle_1\n");
            exit(-1);
        }
    }

    for(i=0;i<=TRUCK_NUM;i++)
    {
        pthread_join(threadFollowVehicle_1[i],NULL);
    }
    pthread_mutex_destroy(&mutexCounter);

    return 0;
}


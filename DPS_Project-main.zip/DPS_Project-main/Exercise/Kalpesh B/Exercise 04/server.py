import socket 
import threading
import random

HEADER = 64
PORT = 5050
SERVER = socket.gethostbyname(socket.gethostname())
ADDR = (SERVER, PORT)
FORMAT = 'utf-8'
DISCONNECT_MESSAGE = "!DISCONNECT"

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(ADDR)

def handle_client(conn, addr):
    connected = True
    while connected:
        msg_length = conn.recv(HEADER).decode(FORMAT)
        if msg_length:
            msg_length = int(msg_length)
            msg = conn.recv(msg_length).decode(FORMAT)
            if msg == DISCONNECT_MESSAGE:
                connected = False
            conn.send("Entered in garden\n".encode(FORMAT))
    conn.close()
        

def start():
    count_east=0
    count_west=0
    server.listen()
    while True:
        conn, addr = server.accept()
        thread = threading.Thread(target=handle_client, args=(conn, addr))
        thread.start()
        num1 = random.choice([0,1,2,3])
        if num1==0:
            if count_west+count_east==100:
                print("Garden is full!!")
            else:
                count_east=count_east+1
                print("Entry from east gate")
        elif num1==1:
            if count_west+count_east==100:
                print("Garden is full!!")
            else:
                count_west=count_west+1
                print("Entry from west gate")
        elif (num1==2):
            if count_west+count_east>0:
                count_east=count_east-1
                print("Exit from east gate")
            else:
                print("Garden is empty")
        elif (num1==3):
            if count_west+count_east>0:
                count_west=count_west-1
                print("Exit from west gate")
            else:
                print("Garden is empty")


        print(f"Count in garden {count_west+count_east} \n")


print("Garden is Open")
start()
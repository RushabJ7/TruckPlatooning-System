#include <iostream>
#include <future>
#include <mutex>
#include <thread>
#include <chrono>
#include <stdlib.h> 

using namespace std;
mutex c_lk ; 
static int count =0 ;

void counter( int numP, int interval_in_ms, string id )
{
    const auto interval = chrono::milliseconds(interval_in_ms);
    for( int i = 0 ; i < numP ; ++i )
    {
        this_thread::sleep_for(interval);
        lock_guard<mutex> guard(c_lk);
        cout << this_thread::get_id()<< " " << id <<'\n'<< flush;
        count++;
    }
}
int main()
{
    int numP=0;
    numP = rand() % 10 + 1;
    auto fut_a = async( launch::async, counter, numP/2, 100, "East" ) ;
    auto fut_b = async( launch::async, counter, ((numP/2)+(numP%2)), 50, "West" ) ;
    //auto fut_c = async( launch::async, counter, ((numP/2)+(numP%2)), 150, "North" ) ;
    //auto fut_d = async( launch::async, counter, ((numP/2)+(numP%2)), 200, "South" ) ;
    
    for( int i = 0 ; i < 10 ; ++i )
    {
        std::this_thread::sleep_for( std::chrono::milliseconds(100) ) ;
        std::lock_guard<std::mutex> guard(c_lk) ;
    }
    
    cout<<"Total Person entered are : "<<count<<endl; 
}
/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

// declaring mutex
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

int numP = 0;

void *Counter(void * tid){
    
    long * myID = (long *)tid;
    int pass = 0;
    static int Count = 0;
    static int inc = 0;
    
    while(Count < numP)
    {
            pthread_mutex_lock(&lock);
            
            printf("Press '1' to pass the turnstile\n");
            scanf("%d", &pass);
            
            printf("This is thread %ld\n", *myID);
            
            if(pass == 1)
            {
                ++Count;
                printf("Counter value = %d\n", Count);
            }
            else
            {
                printf("No Entry done\n");
            }
            
            pthread_mutex_unlock(&lock);
    }
}

int main()
{
    pthread_t tid0;
    pthread_t tid1;

    printf("Set the limit of the number of people in the Garden\n");
    scanf("%d", &numP);
    
    pthread_create(&tid0, NULL, Counter, (void *)&tid0);
    pthread_create(&tid1, NULL, Counter, (void *)&tid1);

    pthread_exit(NULL);

    return 0;
}

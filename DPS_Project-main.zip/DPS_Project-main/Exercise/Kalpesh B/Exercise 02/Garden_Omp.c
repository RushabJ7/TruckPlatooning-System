//C:\Users\lenovo\Documents\First_WS\OpenMPTry
//gcc -o omp_helloc -fopenmp main.c
//omp_helloc.exe
/*#include <omp.h>
 
#include <stdio.h>
 #include <unistd.h>
#include <stdlib.h>
 omp_lock_t writelock;
 int count=0;
 
void counter(int tid, int entryStatus)
{
    #pragma omp critical
    {
        if(entryStatus == 1){
            if(count <= 100){
                count++;
                printf("count = %d , thread = %d \n", count, tid);
            }
        }
        else if(entryStatus == 0)
        {
            if(count > 0){
                count--;
                printf("count = %d , thread = %d \n", count, tid);
            }  
        }
    }
}  

void *westEntry(){
    int myWestEntryCounter = 0;
    while (myWestEntryCounter<=100){
        counter(200, 1);
        myWestEntryCounter++;
        usleep(50);
    }
}

void *eastEntry(){
    int myEastEntryCounter = 0;
    while (myEastEntryCounter<=100){
        counter(300, 1);
        myEastEntryCounter++;
        usleep(50);
    }
}

void *westExit(){
    int myWestExitCounter = 0;
    while (myWestExitCounter<=100){
        counter(400, 0);
        myWestExitCounter++;
        usleep(50);
    }
}

void *eastExit(){
    int myEastExitCounter = 0;
    while (myEastExitCounter<=100){
        counter(500, 0);
        myEastExitCounter++;
        usleep(50);
    }
}

void main()
{
    omp_set_num_threads(4);
    // Beginning of parallel region
    #pragma omp parallel
    {
        eastEntry();
        westEntry();
        eastExit();
        westExit();
    }
    // Ending of parallel region
}*/

#include <stdio.h> 
#include <unistd.h> 
#include <omp.h> 
int count = 0; 
double start,delta;
void counter(int id,int dir){ 

    if(count<=100)
    { 
        #pragma omp critical
        {
        if(dir==1){
            count++;
            printf("East Entry: ");
        }else if(dir==2){
            count++;
            printf("West Entry: ");
        }else if(dir==-1){
            count--;
            printf("East Exit: ");
        }
        else if (dir==-2){
            count--;
            printf("West Exit: ");
        }
        printf("count: %d, pid: %d\n",count,id); 
        }
    }
}

int main(void){ 
    start = omp_get_wtime();
    #pragma omp parallel for num_threads(4) schedule(static) 
    for(int i=0; i<100;i++){ 
        counter(omp_get_thread_num(),1);
        usleep(1000);
        counter(omp_get_thread_num(),2);
        usleep(1000);
        counter(omp_get_thread_num(),-1);
        usleep(1000);
        counter(omp_get_thread_num(),-2); 
        usleep(1000);
    }
    delta = omp_get_wtime() - start;
    printf("computed in %.4g seconds\n", delta); 
}

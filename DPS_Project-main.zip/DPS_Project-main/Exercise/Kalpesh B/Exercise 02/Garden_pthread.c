#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int count = 0;
pthread_mutex_t mutexCounter = PTHREAD_MUTEX_INITIALIZER;

int counter(int tid, int entryStatus)
{
    pthread_mutex_lock(&mutexCounter);
    if(entryStatus == 1){
        if(count <= 100){
            count++;
            printf("count = %d , thread = %d \n", count, tid);
            pthread_mutex_unlock(&mutexCounter);
            return 1;   
        }
    }
    else if(entryStatus == 0)
    {
        if(count > 0){
            count--;
            printf("count = %d , thread = %d \n", count, tid);
            pthread_mutex_unlock(&mutexCounter);
            return 1;   
        }  
    }
    else
    {
        pthread_mutex_unlock(&mutexCounter);
        return 1;   
    }
    pthread_mutex_unlock(&mutexCounter);
    return 0;    
}

void *westEntry(){
    int myWestEntryCounter = 0;
    while (myWestEntryCounter<=100){
        printf("WEn : ");
        counter(200, 1);
        myWestEntryCounter++;
        usleep(50000);
    }
}

void *eastEntry(){
    int myEastEntryCounter = 0;
    while (myEastEntryCounter<=100){
        printf("EEn : ");
        counter(300, 1);
        myEastEntryCounter++;
        usleep(50000);
    }
}

void *westExit(){
    int myWestExitCounter = 0;
    while (myWestExitCounter<=100){
        printf("WEx : ");
        counter(400, 0);
        myWestExitCounter++;
        usleep(100000);
    }
}

void *eastExit(){
    int myEastExitCounter = 0;
    while (myEastExitCounter<=100){
        printf("EEx : ");
        counter(500, 0);
        myEastExitCounter++;
        usleep(100000);
    }
}

int main(int argc, char *argv[])
{
  int thread;
  pthread_t threadWestEntry;
  pthread_t threadEastEntry;
  pthread_t threadWestExit;
  pthread_t threadEastExit;
  
  printf("create West Entry\n");
  thread = pthread_create(&threadWestEntry, NULL, westEntry, NULL);
  if(thread){
      printf("ERROR: return code from pthread_create() is %d\n", thread);
      exit(-1);
  }
  
  printf("create East Entry\n");
  thread = pthread_create(&threadEastEntry, NULL, eastEntry, NULL);
  if(thread){
      printf("ERROR: return code from pthread_create() is %d\n", thread);
      exit(-1);
  }
  
  printf("create West Exit\n");
  thread = pthread_create(&threadWestExit, NULL, westExit, NULL);
  if(thread){
      printf("ERROR: return code from pthread_create() is %d\n", thread);
      exit(-1);
  }
  
  printf("create East Exit\n");
  thread = pthread_create(&threadEastExit, NULL, eastExit, NULL);
  if(thread){
      printf("ERROR: return code from pthread_create() is %d\n", thread);
      exit(-1);
  }
  
  pthread_exit(NULL);
}


